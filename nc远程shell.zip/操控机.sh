nc -lp 6667 &
while :
do
    nc -lp 6668
done